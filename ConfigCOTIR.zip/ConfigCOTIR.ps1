﻿Configuration ConfigCOTIR
{
	Import-DSCResource -ModuleName xActiveDirectory,xPendingReboot,StorageDsc,xComputerManagement,PSDesiredStateConfiguration,xCertificate
  Node $AllNodes.NodeName
  {
  	LocalConfigurationManager            
	{            
		ActionAfterReboot = 'ContinueConfiguration'            
		ConfigurationMode = 'ApplyOnly'            
		RebootNodeIfNeeded = $true            
	}

	#Install Message Queuing   
	WindowsFeature MessageQueueFeature 
	{ 
	 Ensure = “Present” 
	 Name = “MSMQ” 
	}

	#Install Message Queuing - Message Queuing Services   
	WindowsFeature MessageQueueServices 
	{ 
	 Ensure = “Present” 
	 Name = “MSMQ-Services” 
	}

	#Install Message Queuing Services - Message Queuing Server   
	WindowsFeature MessageQueueServer 
	{ 
	 Ensure = “Present” 
	 Name = “MSMQ-Server” 
	}
	
  }
} 